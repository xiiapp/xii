#!/bin/bash

curl https://get.acme.sh | sh -s email=xii@exmaple.com && alias acme.sh=~/.acme.sh/acme.sh