存储构建docker-compose.yml文件 和 .env 文件的头部信息。

即通用的。

