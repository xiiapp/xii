本目录用来存放构建docker-compose.yml的容器代码片段、自定义变量、配置文件和目录
具体说明请参考： docs/开发流程.md